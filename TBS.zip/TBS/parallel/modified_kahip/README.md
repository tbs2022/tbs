KaHIP v0.61
=====

The graph partitioning framework KaHIP -- Karlsruhe High Quality Partitioning.

Main project site:
http://algo2.iti.kit.edu/documents/kahip/index.html

