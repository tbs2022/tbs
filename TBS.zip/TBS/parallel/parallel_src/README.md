# parallel_partitioning
This is the parallel partitioning code  of KaHIP.

