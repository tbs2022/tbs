/******************************************************************************
 * node_ordering.cpp         
 * *
 * Source of KaHIP -- Karlsruhe High Quality Partitioning.
 * Christian Schulz <christian.schulz.phone@gmail.com>
 *****************************************************************************/


#include "node_ordering.h"

node_ordering::node_ordering() {
                
}

node_ordering::~node_ordering() {
                
}

